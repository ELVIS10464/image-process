﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using MiM_iVision;

namespace hw2
{
    public partial class Form1 : Form
    {
        public IntPtr GrayImage = iImage.CreateGrayiImage();
        public IntPtr GrayImage2 = iImage.CreateGrayiImage();
        public IntPtr hbitmap, hbitmap2;
        E_iVision_ERRORS err = E_iVision_ERRORS.E_NULL;
        E_iVision_ERRORS err2 = E_iVision_ERRORS.E_NULL;
        int last_dir = 0;
        double last_angle = 0;
        int size_num = 0;
        TextBox[] textbox_array = new TextBox[0];

        public Form1()
        {   
            InitializeComponent();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            iImage.DestroyiImage(GrayImage);
        }

        private void btn_Loadimage_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "BMP file |* .bmp";
            string filepath;                                       // Declare a string type of variable
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                filepath = openFileDialog1.FileName;
                err = iImage.iReadImage(GrayImage, filepath);
                err2 = iImage.iReadImage(GrayImage2, filepath);
                if (err == E_iVision_ERRORS.E_OK)
                {
                    hbitmap = iImage.iGetBitmapAddress(GrayImage); //Get GrayImage's hbitmap  
                    hbitmap2 = iImage.iGetBitmapAddress(GrayImage2);
                    if (pictureBox1.Image != null)                 //If there is an image on the Picturebox   
                        pictureBox1.Image.Dispose();               //clear Picturebox image                  
                    pictureBox1.Image = System.Drawing.Image.FromHbitmap(hbitmap);
                    pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;  //Set PictureBox size mode
                    pictureBox1.Refresh();                         // refresh to update the Picturebox
                }
                else
                    MessageBox.Show(err.ToString(), "Error");
            }
        }

        private void btn_pow_Click(object sender, EventArgs e)
        {
            int Width = iImage.GetWidth(GrayImage);        // Get image width
            int Height = iImage.GetHeight(GrayImage);      // Get image height
            double gamma = Convert.ToDouble(tb_gamma.Text);
            double c_con = Convert.ToDouble(tb_c.Text);
            byte[,] Graymatrix = new byte[Height, Width];
            byte[,] Graymatrix_enh = new byte[Height, Width];                     

            err = iImage.iPointerFromiImage(GrayImage, ref Graymatrix[0, 0], Width, Height);
            if (err != E_iVision_ERRORS.E_OK)              // Check the status from functions
            {
                MessageBox.Show(err.ToString(), "ERROR");  // This will open a MessagBox for warning.
                return;                                    // End "Binary Threshold Event Function" 
            }
            // start sliding the matrix         
            for (int i = 0; i < Height; i++)               // i index for cols ( 0~Hight-1)(Because that matrix index is start from 0)
            {
                for (int j = 0; j < Width; j++)            // j index for rows ( 0~Width-1)
                {
                    Graymatrix_enh[i, j] = (Byte)(c_con * Math.Pow((double)Graymatrix[i, j], gamma));
                }
            }

            IntPtr imgPtr = iImage.iVarPtr(ref Graymatrix_enh[0, 0]);
            err2 = iImage.iPointerToiImage(GrayImage2, imgPtr, Width, Height);
            if (err2 != E_iVision_ERRORS.E_OK)              // Check the status from functions
            {
                MessageBox.Show(err2.ToString(), "Error");
                return;
            }
            hbitmap2 = iImage.iGetBitmapAddress(GrayImage2); // transform to hbitmap for PictureBox
            if (pictureBox2.Image != null)                 //If there is an image on the Picturebox
                pictureBox2.Image.Dispose();               //clear Picturebox image
            pictureBox2.Image = System.Drawing.Image.FromHbitmap(hbitmap2); // shows image
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;        //Set PictureBox size mode
            pictureBox2.Refresh();                         // refresh to update the Picturebox

            chart_org.ChartAreas[0].AxisX.Title = "rk";
            chart_af.ChartAreas[0].AxisX.Title = "rk";
            chart_org.ChartAreas[0].AxisY.Title = "nk";
            chart_af.ChartAreas[0].AxisY.Title = "nk";
            chart_org.Series.Clear();
            chart_af.Series.Clear();
          
            chart_org.Series.Add("nk(rk)");
            chart_af.Series.Add("nk(rk)");
            
            chart_org.Series["nk(rk)"].ChartType = SeriesChartType.Column;
            chart_org.Series["nk(rk)"].XValueType = ChartValueType.Int32;
            chart_org.Series["nk(rk)"].YValueType = ChartValueType.Int32;
            chart_af.Series["nk(rk)"].ChartType = SeriesChartType.Column;
            chart_af.Series["nk(rk)"].XValueType = ChartValueType.Int32;
            chart_af.Series["nk(rk)"].YValueType = ChartValueType.Int32;
            
            chart_org.ChartAreas[0].AxisY.Minimum = 0;
            chart_org.ChartAreas[0].AxisY.Maximum = 25000;
            chart_org.ChartAreas[0].AxisX.Minimum = 0;
            chart_org.ChartAreas[0].AxisX.Maximum = 255;
            chart_af.ChartAreas[0].AxisY.Minimum = 0;
            chart_af.ChartAreas[0].AxisY.Maximum = 25000;
            chart_af.ChartAreas[0].AxisX.Minimum = 0;
            chart_af.ChartAreas[0].AxisX.Maximum = 255;
            
            int[] gray_level = new int[256];
            int[] gray_level_af = new int[256];
            for(int i = 0; i < gray_level.Length; i++)
            {
                gray_level[i] = i;
            }

            for (int i = 0; i < Height; i++)              
            {
                for (int j = 0; j < Width; j++)           
                {
                    gray_level_af[Graymatrix[i, j]] = Graymatrix_enh[i, j];
                }
            }
         
            int[] gray_org_count = new int[256];
            int[] gray_af_count = new int[256];          
            for (int i = 0; i < Height; i++)
            {
                for (int j = 0; j < Width; j++)
                {
                    gray_org_count[Graymatrix[i, j]] = gray_org_count[Graymatrix[i, j]] + 1;                                      
                    gray_af_count[Graymatrix_enh[i, j]] = gray_af_count[Graymatrix_enh[i, j]] + 1;                    
                }
            }
           
            chart_org.Series["nk(rk)"].Points.DataBindXY(gray_level, gray_org_count);
            chart_af.Series["nk(rk)"].Points.DataBindXY(gray_level, gray_af_count);          
            
        }

        private void btn_his_Click(object sender, EventArgs e)
        {
            int Width = iImage.GetWidth(GrayImage);        // Get image width
            int Height = iImage.GetHeight(GrayImage);      // Get image height
            byte[,] Graymatrix = new byte[Height, Width];
            byte[,] Graymatrix_his = new byte[Height, Width];
            int[] gray_level = new int[256];
            int[] gray_level_af = new int[256];           
            int gray_level_count = 0;
            for (int i = 0; i < gray_level.Length; i++)
            {
                gray_level[i] = i;               
            }
            int[] gray_org_count = new int[256];
            int[] gray_af_count = new int[256];
            double[] gray_org_pr = new double[256];
            double[] gray_af_pr = new double[256];

            err = iImage.iPointerFromiImage(GrayImage, ref Graymatrix[0, 0], Width, Height);
            if (err != E_iVision_ERRORS.E_OK)              // Check the status from functions
            {
                MessageBox.Show(err.ToString(), "ERROR");  // This will open a MessagBox for warning.
                return;                                    // End "Binary Threshold Event Function" 
            }           
            for (int i = 0; i < Height; i++)//統計每個灰階值出現次數    
            {
                for (int j = 0; j < Width; j++)            
                {
                    gray_org_count[Graymatrix[i, j]] = gray_org_count[Graymatrix[i, j]] + 1;
                }
            }
            for (int i = 0; i < gray_level.Length; i++)//算出各個灰階值的 PDF
            {
                gray_org_pr[i] = gray_org_count[i] / (double)(Width * Height);
            }
            for(int i = 0; i < 256; i++) //將PDF 做累加求出 CDF
            {
                for(int j = 0; j <= i; j++)
                {
                    gray_af_pr[i] = gray_af_pr[i] + gray_org_pr[j];                       
                }
            }           
            for (int i = 0; i < Height; i++)
            {
                for (int j = 0; j < Width; j++)
                {
                    Graymatrix_his[i, j] = (Byte)(gray_af_pr[Graymatrix[i, j]] * 255);
                    gray_level_af[Graymatrix[i, j]] = Graymatrix_his[i, j];
                }
            } 
            for(int i = 0; i < gray_level_af.Length; i++)
            {
                if(gray_level_af[i] != 0)
                {
                    gray_level_count += 1;
                }
            }
            int[] gray_level_af_x = new int[gray_level_count];
            int[] gray_level_af_y = new int[gray_level_count];
            int count_index = 0;
            for(int i = 0; i < gray_level_af.Length; i++)
            {
                if (gray_level_af[i] != 0)
                {
                    gray_level_af_x[count_index] = i;
                    gray_level_af_y[count_index] = gray_level_af[i];
                    count_index += 1;
                }
            }
            for (int i = 0; i < Height; i++)
            {
                for (int j = 0; j < Width; j++)
                {
                    gray_af_count[Graymatrix_his[i, j]] += 1;
                }
            }

            IntPtr imgPtr = iImage.iVarPtr(ref Graymatrix_his[0, 0]);
            err = iImage.iPointerToiImage(GrayImage, imgPtr, Width, Height);
            if (err != E_iVision_ERRORS.E_OK)              // Check the status from functions
            {
                MessageBox.Show(err.ToString(), "Error");
                return;
            }
            hbitmap = iImage.iGetBitmapAddress(GrayImage); // transform to hbitmap for PictureBox
            if (pictureBox2.Image != null)                 //If there is an image on the Picturebox
                pictureBox2.Image.Dispose();               //clear Picturebox image
            pictureBox2.Image = System.Drawing.Image.FromHbitmap(hbitmap); // shows image
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;        //Set PictureBox size mode
            pictureBox2.Refresh();                         // refresh to update the Picturebox

            chart_org.ChartAreas[0].AxisX.Title = "rk";
            chart_af.ChartAreas[0].AxisX.Title = "rk";
            chart_org.ChartAreas[0].AxisY.Title = "nk";
            chart_af.ChartAreas[0].AxisY.Title = "nk";
            chart_org.Series.Clear();
            chart_af.Series.Clear();
            chart_curves.Series.Clear();
            chart_org.Series.Add("nk(rk)");
            chart_af.Series.Add("nk(rk)");
            chart_curves.Series.Add("gray");
            chart_org.Series["nk(rk)"].ChartType = SeriesChartType.Column;
            chart_org.Series["nk(rk)"].XValueType = ChartValueType.Int32;
            chart_org.Series["nk(rk)"].YValueType = ChartValueType.Int32;
            chart_af.Series["nk(rk)"].ChartType = SeriesChartType.Column;
            chart_af.Series["nk(rk)"].XValueType = ChartValueType.Int32;
            chart_af.Series["nk(rk)"].YValueType = ChartValueType.Int32;
            chart_curves.Series["gray"].ChartType = SeriesChartType.Line;
            chart_curves.Series["gray"].XValueType = ChartValueType.Int32;
            chart_curves.Series["gray"].YValueType = ChartValueType.Int32;
            chart_org.ChartAreas[0].AxisY.Minimum = 0;
            chart_org.ChartAreas[0].AxisY.Maximum = 25000;
            chart_org.ChartAreas[0].AxisX.Minimum = 0;
            chart_org.ChartAreas[0].AxisX.Maximum = 255;
            chart_af.ChartAreas[0].AxisY.Minimum = 0;
            chart_af.ChartAreas[0].AxisY.Maximum = 25000;
            chart_af.ChartAreas[0].AxisX.Minimum = 0;
            chart_af.ChartAreas[0].AxisX.Maximum = 255;
            chart_curves.ChartAreas[0].AxisY.Minimum = 0;
            chart_curves.ChartAreas[0].AxisY.Maximum = 255;
            chart_curves.ChartAreas[0].AxisX.Minimum = 0;
            chart_curves.ChartAreas[0].AxisX.Maximum = 255;

            chart_org.Series["nk(rk)"].Points.DataBindXY(gray_level, gray_org_count);
            chart_af.Series["nk(rk)"].Points.DataBindXY(gray_level, gray_af_count);
            
            for (int i = 0;i < gray_level_af_x.Length; i++)
            {                                
                chart_curves.Series["gray"].Points.AddXY(gray_level_af_x[i], gray_level_af_y[i]);                          
            }                      
        }

        private void bt_lap_Click(object sender, EventArgs e)
        {
            int Width = iImage.GetWidth(GrayImage);        // Get image width
            int Height = iImage.GetHeight(GrayImage);      // Get image height           
            byte[,] Graymatrix = new byte[Height, Width];
            byte[,] Graymatrix_af = new byte[Height, Width];         
            err = iImage.iPointerFromiImage(GrayImage, ref Graymatrix[0, 0], Width, Height);
            if (err != E_iVision_ERRORS.E_OK)              // Check the status from functions
            {
                MessageBox.Show(err.ToString(), "ERROR");  // This will open a MessagBox for warning.
                return;                                    // End "Binary Threshold Event Function" 
            }
            int[,] filter_array = new int[size_num, size_num];
            for(int i = 0; i < size_num; i++)
            {
                for(int j = 0; j < size_num; j++)
                {
                    filter_array[i, j] = Convert.ToInt32(textbox_array[i * size_num + j].Text);
                    label3.Text += textbox_array[i * size_num + j].Text;
                }
            }
            int number = 0;
            for(int i = 0; i < Height; i++)
            {
                for(int j = 0; j < Width; j++)
                {
                    number = 0;
                    for(int s = -1 * (size_num / 2); s < (size_num / 2) + 1; s++)
                    {
                        for(int t = -1 * (size_num / 2); t < (size_num / 2) + 1; t++)
                        {
                            if((i + s) >= 0 && (i + s) < Height && (j + t) >= 0 && (j + t) < Width)
                            {
                                number += Graymatrix[i + s, j + t] * filter_array[s + (size_num / 2), t + (size_num / 2)];
                            }
                            else
                            {
                                number += 0 * filter_array[s + (size_num / 2), t + (size_num / 2)];
                            }
                        }
                    }
                    if(number > 255)
                    {
                        number = 255;
                    }
                    if(number < 0)
                    {
                        number = 0;
                    }
                    Graymatrix_af[i, j] = (Byte)number;
                }
            }

            IntPtr imgPtr = iImage.iVarPtr(ref Graymatrix_af[0, 0]);
            err2 = iImage.iPointerToiImage(GrayImage2, imgPtr, Width, Height);
            if (err2 != E_iVision_ERRORS.E_OK)              // Check the status from functions
            {
                MessageBox.Show(err2.ToString(), "Error");
                return;
            }

            hbitmap2 = iImage.iGetBitmapAddress(GrayImage2); // transform to hbitmap for PictureBox
            if (pictureBox2.Image != null)                 //If there is an image on the Picturebox
                pictureBox2.Image.Dispose();               //clear Picturebox image
            pictureBox2.Image = System.Drawing.Image.FromHbitmap(hbitmap2); // shows image
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;        //Set PictureBox size mode
            pictureBox2.Refresh();                         // refresh to update the Picturebox
        }

        private void bt_check_Click(object sender, EventArgs e)
        {           
            size_num = Convert.ToInt32(tb_size.Text);
            Array.Resize(ref textbox_array, size_num * size_num);
            int Location_x, Location_y;
            for(int i = 0; i < size_num; i++)
            {
                for(int j = 0; j < size_num; j++)
                {
                    textbox_array[i * size_num + j] = new TextBox();
                    Location_x = 700 + (i * 30);
                    Location_y = 20 + (j * 30);
                    textbox_array[i * size_num + j].Text = "1";
                    textbox_array[i * size_num + j].Width = 20;
                    textbox_array[i * size_num + j].Height = 20;
                    textbox_array[i * size_num + j].Location = new Point(Location_x, Location_y);
                    this.Controls.Add(textbox_array[i * size_num + j]);
                }
            }
        }

        private void btn_mat_Click(object sender, EventArgs e)
        {
            int Width = iImage.GetWidth(GrayImage);        // Get image width
            int Height = iImage.GetHeight(GrayImage);      // Get image height
            byte[,] Graymatrix = new byte[Height, Width];
            byte[,] Graymatrix_mat = new byte[Height, Width];
            int[] gray_level = new int[256];
            int[] gray_level_af = new int[256];

            double[] pdf = new double[256];
            int[] means = new int[2] { 38, 191 };
            int[] stds = new int[2] { 13, 13 };
            double[] ampl = new double[2] { 0.93, 0.07 };
            double bias = 0.002;

            for (int i = 0; i < gray_level.Length; i++)
            {
                gray_level[i] = i;                
            }
            int[] gray_org_count = new int[256];
            int[] gray_af_count = new int[256];
            double[] gray_org_pr = new double[256];
            double[] gray_af_pr = new double[256];

            err = iImage.iPointerFromiImage(GrayImage, ref Graymatrix[0, 0], Width, Height);
            if (err != E_iVision_ERRORS.E_OK)              // Check the status from functions
            {
                MessageBox.Show(err.ToString(), "ERROR");  // This will open a MessagBox for warning.
                return;                                    // End "Binary Threshold Event Function" 
            }
            double pdf_total = 0;
            for (int j = 0; j < pdf.Length; j++)
            {
                for (int i = 0; i < 2; i++)
                {
                    pdf[j] += ampl[i] * Math.Exp(-1 * Math.Pow(j - means[i], 2) / (2 * stds[i] * stds[i])) / (stds[i] * Math.Sqrt(2 * Math.PI));
                }
                pdf[j] += bias;              
                pdf_total += pdf[j];
            }
            double[] pdf_nor = new double[256];
            for(int i = 0; i < pdf.Length; i++)
            {
                pdf_nor[i] = pdf[i] / pdf_total;
            }

            // start sliding the matrix
            for (int i = 0; i < Height; i++)//統計每個灰階值出現次數              
            {
                for (int j = 0; j < Width; j++)
                {
                    gray_org_count[Graymatrix[i, j]] = gray_org_count[Graymatrix[i, j]] + 1;
                }
            }

            for (int i = 0; i < gray_level.Length; i++)//每個灰階值分布機率
            {
                gray_org_pr[i] = gray_org_count[i] / (double)(Width * Height);
            }

            for (int i = 0; i < 256; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    gray_af_pr[i] = gray_af_pr[i] + pdf_nor[j];
                }
            }
            
            for (int i = 0; i < Height; i++)
            {
                for (int j = 0; j < Width; j++)
                {
                    Graymatrix_mat[i, j] = (Byte)(gray_af_pr[Graymatrix[i, j]] * 255);
                    gray_level_af[Graymatrix[i, j]] = Graymatrix_mat[i, j];
                }
            }

            for (int i = 0; i < Height; i++)
            {
                for (int j = 0; j < Width; j++)
                {
                    gray_af_count[Graymatrix_mat[i, j]] += 1;
                }
            }

            IntPtr imgPtr = iImage.iVarPtr(ref Graymatrix_mat[0, 0]);
            err = iImage.iPointerToiImage(GrayImage, imgPtr, Width, Height);
            if (err != E_iVision_ERRORS.E_OK)              // Check the status from functions
            {
                MessageBox.Show(err.ToString(), "Error");
                return;
            }
            hbitmap = iImage.iGetBitmapAddress(GrayImage); // transform to hbitmap for PictureBox
            if (pictureBox2.Image != null)                 //If there is an image on the Picturebox
                pictureBox2.Image.Dispose();               //clear Picturebox image
            pictureBox2.Image = System.Drawing.Image.FromHbitmap(hbitmap); // shows image
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;        //Set PictureBox size mode
            pictureBox2.Refresh();                         // refresh to update the Picturebox

            chart_org.ChartAreas[0].AxisX.Title = "rk";
            chart_af.ChartAreas[0].AxisX.Title = "rk";
            chart_org.ChartAreas[0].AxisY.Title = "nk";
            chart_af.ChartAreas[0].AxisY.Title = "nk";
            chart_org.Series.Clear();
            chart_af.Series.Clear();
            chart_curves.Series.Clear();
            chart_org.Series.Add("nk(rk)");
            chart_af.Series.Add("nk(rk)");
            chart_curves.Series.Add("gray");
            chart_org.Series["nk(rk)"].ChartType = SeriesChartType.Column;
            chart_org.Series["nk(rk)"].XValueType = ChartValueType.Int32;
            chart_org.Series["nk(rk)"].YValueType = ChartValueType.Int32;
            chart_af.Series["nk(rk)"].ChartType = SeriesChartType.Column;
            chart_af.Series["nk(rk)"].XValueType = ChartValueType.Int32;
            chart_af.Series["nk(rk)"].YValueType = ChartValueType.Int32;
            chart_curves.Series["gray"].ChartType = SeriesChartType.Line;
            chart_curves.Series["gray"].XValueType = ChartValueType.Int32;
            chart_curves.Series["gray"].YValueType = ChartValueType.Int32;
            chart_org.ChartAreas[0].AxisY.Minimum = 0;
            chart_org.ChartAreas[0].AxisY.Maximum = 25000;
            chart_org.ChartAreas[0].AxisX.Minimum = 0;
            chart_org.ChartAreas[0].AxisX.Maximum = 255;
            chart_af.ChartAreas[0].AxisY.Minimum = 0;
            chart_af.ChartAreas[0].AxisY.Maximum = 25000;
            chart_af.ChartAreas[0].AxisX.Minimum = 0;
            chart_af.ChartAreas[0].AxisX.Maximum = 255;
            chart_curves.ChartAreas[0].AxisY.Minimum = 0;
            chart_curves.ChartAreas[0].AxisY.Maximum = 255;
            chart_curves.ChartAreas[0].AxisX.Minimum = 0;
            chart_curves.ChartAreas[0].AxisX.Maximum = 255;

            chart_org.Series["nk(rk)"].Points.DataBindXY(gray_level, gray_org_count);
            chart_af.Series["nk(rk)"].Points.DataBindXY(gray_level, gray_af_count);
            for (int i = 0; i < gray_level.Length; i++)
            {
                chart_curves.Series["gray"].Points.AddXY(gray_level[i], gray_level_af[i]);
            }

        }
      

        private void btn_rotating_Click(object sender, EventArgs e)
        {   
            int Width = iImage.GetWidth(GrayImage);        // Get image width
            int Height = iImage.GetHeight(GrayImage);      // Get image height
            int trans_x = (int)(Width / 2);
            int trans_y = (int)(Height / 2);
            int degree = Convert.ToInt32(tb_degree.Text);
            double angle = Math.PI * degree / 180.0;
            byte[,] Graymatrix = new byte[Height, Width];
            int rotat_Width = 0, rotat_Height = 0;
            if ((last_dir == 1 && rad_cl.Checked == true) || (last_dir == 2 && rad_uncl.Checked == true) || last_dir == 0)
            {   
                rotat_Width = (int)(Width * Math.Cos(angle)) + (int)(Width * Math.Sin(angle)) + 1;
                rotat_Height = (int)(Height * Math.Cos(angle)) + (int)(Height * Math.Sin(angle)) + 1;               
            } 
            if ((last_dir == 2 && rad_cl.Checked == true) || (last_dir == 1 && rad_uncl.Checked == true))
            {   
                if (angle > last_angle)
                {
                    rotat_Width = (int)(Width * Math.Cos(angle - last_angle)) + (int)(Width * Math.Sin(angle - last_angle)) + 1;
                    rotat_Height = (int)(Height * Math.Cos(angle - last_angle)) + (int)(Height * Math.Sin(angle - last_angle)) + 1;
                }
                else
                {
                    rotat_Width = (int)(Width * Math.Cos(angle)) - (int)(Width * Math.Sin(angle)) + 1;
                    rotat_Height = (int)(Height * Math.Cos(angle)) - (int)(Height * Math.Sin(angle)) + 1;
                }
                
            }
            int rotat_trans_x = (int)(rotat_Width/2);
            int rotat_trans_y = (int)(rotat_Height/2);
            byte[,] Graymatrix_rotat = new byte[rotat_Height, rotat_Width];

            last_angle = angle;
            if (rad_cl.Checked == true)
            {
                last_dir = 1;
            }
            if (rad_uncl.Checked == true)
            {
                last_dir = 2;
            }

            err = iImage.iPointerFromiImage(GrayImage, ref Graymatrix[0, 0], Width, Height);
            if (err != E_iVision_ERRORS.E_OK)              // Check the status from functions
            {
                MessageBox.Show(err.ToString(), "ERROR");  // This will open a MessagBox for warning.
                return;                                    // End "Binary Threshold Event Function" 
            }
            // start sliding the matrix
            double target_x, target_y;
            target_x = target_y = 0;
            for (int i = 0; i < rotat_Height; i++)               // i index for cols ( 0~Hight-1)(Because that matrix index is start from 0)
            {
                for (int j = 0; j < rotat_Width; j++)            // j index for rows ( 0~Width-1)
                {
                    if (rad_cl.Checked == true)
                    {
                        target_x = Math.Cos(angle) * (i) + (-1) * Math.Sin(angle) * (j)  + (rotat_trans_y * Math.Sin(angle) - rotat_trans_x * Math.Cos(angle)) + trans_x;
                        target_y = Math.Sin(angle) * (i) + Math.Cos(angle) * (j) + ((-1) * rotat_trans_y * Math.Cos(angle) - rotat_trans_x * Math.Sin(angle)) + trans_y;
                    }

                    if (rad_uncl.Checked == true)
                    {
                        target_x = Math.Cos(angle) * (i) + Math.Sin(angle) * (j) + ((-1) * rotat_trans_y * Math.Sin(angle) - rotat_trans_x * Math.Cos(angle)) + trans_x;
                        target_y = (-1) * Math.Sin(angle) * (i) + Math.Cos(angle) * (j) + ((-1) * rotat_trans_y * Math.Cos(angle) + rotat_trans_x * Math.Sin(angle)) + trans_y;
                    }

                    if (target_x > 0 && target_x < Width && target_y > 0 && target_y < Height)
                    {
                        if (rad_1.Checked == true) //Nearest-neighbor
                        {
                            Graymatrix_rotat[i, j] = Graymatrix[(int)Math.Floor(target_x), (int)Math.Floor(target_y)];
                        }
                    }
                    if (target_x > 0 && target_x < Width - 1 && target_y > 0 && target_y < Height - 1) { 
                        if (rad_2.Checked == true) //bilinear interpolation
                        {
                            int a_1, a_2, b_1, b_2;
                            double u, v;
                            a_1 = (int)Math.Floor(target_x);
                            a_2 = (int)Math.Ceiling(target_x);
                            b_1 = (int)Math.Floor(target_y);
                            b_2 = (int)Math.Ceiling(target_y);
                            u = target_x - a_1;
                            v = target_y - b_1;
                            Graymatrix_rotat[i, j] = (Byte)((1 - u) * (1 - v) * Graymatrix[a_1, b_1] +
                            (1 - u) * v * Graymatrix[a_1, b_2] + u * (1 - v) * Graymatrix[a_2, b_1] +
                            u * v * Graymatrix[a_2, b_2]);
                        }
                    }
                }
            }
            //label2.Text = rotat_Height.ToString();
            //label3.Text = rotat_Width.ToString();
            IntPtr imgPtr = iImage.iVarPtr(ref Graymatrix_rotat[0, 0]);
            iImage.iImageResize(GrayImage, rotat_Height, rotat_Width);
            err = iImage.iPointerToiImage(GrayImage, imgPtr, rotat_Height, rotat_Width);
            if (err != E_iVision_ERRORS.E_OK)              // Check the status from functions
            {
                MessageBox.Show(err.ToString(), "Error");
                return;
            }

            hbitmap = iImage.iGetBitmapAddress(GrayImage); // transform to hbitmap for PictureBox
            if (pictureBox2.Image != null)                 //If there is an image on the Picturebox
                pictureBox2.Image.Dispose();               //clear Picturebox image
            pictureBox2.Image = System.Drawing.Image.FromHbitmap(hbitmap); // shows image
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;        //Set PictureBox size mode
            pictureBox2.Refresh();                         // refresh to update the Picturebox
        }
    }
}
