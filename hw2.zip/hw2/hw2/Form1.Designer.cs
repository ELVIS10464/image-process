﻿namespace hw2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.btn_Loadimage = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btn_rotating = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_degree = new System.Windows.Forms.TextBox();
            this.rad_1 = new System.Windows.Forms.RadioButton();
            this.rad_2 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rad_cl = new System.Windows.Forms.RadioButton();
            this.rad_uncl = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_pow = new System.Windows.Forms.Button();
            this.btn_his = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_gamma = new System.Windows.Forms.TextBox();
            this.chart_org = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart_af = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_c = new System.Windows.Forms.TextBox();
            this.btn_mat = new System.Windows.Forms.Button();
            this.chart_curves = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tb_size = new System.Windows.Forms.TextBox();
            this.bt_lap = new System.Windows.Forms.Button();
            this.bt_check = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart_org)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart_af)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart_curves)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Loadimage
            // 
            this.btn_Loadimage.Location = new System.Drawing.Point(1562, 12);
            this.btn_Loadimage.Name = "btn_Loadimage";
            this.btn_Loadimage.Size = new System.Drawing.Size(189, 86);
            this.btn_Loadimage.TabIndex = 0;
            this.btn_Loadimage.Text = "Loadimage";
            this.btn_Loadimage.UseVisualStyleBackColor = true;
            this.btn_Loadimage.Click += new System.EventHandler(this.btn_Loadimage_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(68, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(339, 343);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(505, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(337, 344);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // btn_rotating
            // 
            this.btn_rotating.Location = new System.Drawing.Point(1562, 134);
            this.btn_rotating.Name = "btn_rotating";
            this.btn_rotating.Size = new System.Drawing.Size(189, 91);
            this.btn_rotating.TabIndex = 3;
            this.btn_rotating.Text = "Rotating";
            this.btn_rotating.UseVisualStyleBackColor = true;
            this.btn_rotating.Click += new System.EventHandler(this.btn_rotating_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(1346, 254);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 24);
            this.label1.TabIndex = 4;
            this.label1.Text = "degree:";
            // 
            // tb_degree
            // 
            this.tb_degree.Location = new System.Drawing.Point(1433, 253);
            this.tb_degree.Name = "tb_degree";
            this.tb_degree.Size = new System.Drawing.Size(100, 25);
            this.tb_degree.TabIndex = 5;
            // 
            // rad_1
            // 
            this.rad_1.AutoSize = true;
            this.rad_1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.rad_1.Location = new System.Drawing.Point(6, 24);
            this.rad_1.Name = "rad_1";
            this.rad_1.Size = new System.Drawing.Size(156, 24);
            this.rad_1.TabIndex = 7;
            this.rad_1.TabStop = true;
            this.rad_1.Text = "Nearest-neighbor";
            this.rad_1.UseVisualStyleBackColor = true;
            // 
            // rad_2
            // 
            this.rad_2.AutoSize = true;
            this.rad_2.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.rad_2.Location = new System.Drawing.Point(6, 54);
            this.rad_2.Name = "rad_2";
            this.rad_2.Size = new System.Drawing.Size(182, 24);
            this.rad_2.TabIndex = 8;
            this.rad_2.TabStop = true;
            this.rad_2.Text = "bilinear interpolation";
            this.rad_2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rad_1);
            this.groupBox1.Controls.Add(this.rad_2);
            this.groupBox1.Font = new System.Drawing.Font("新細明體", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(1328, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "method";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rad_cl);
            this.groupBox2.Controls.Add(this.rad_uncl);
            this.groupBox2.Font = new System.Drawing.Font("新細明體", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox2.Location = new System.Drawing.Point(1328, 134);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 100);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "方向";
            // 
            // rad_cl
            // 
            this.rad_cl.AutoSize = true;
            this.rad_cl.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.rad_cl.Location = new System.Drawing.Point(6, 24);
            this.rad_cl.Name = "rad_cl";
            this.rad_cl.Size = new System.Drawing.Size(90, 24);
            this.rad_cl.TabIndex = 7;
            this.rad_cl.TabStop = true;
            this.rad_cl.Text = "順時針";
            this.rad_cl.UseVisualStyleBackColor = true;
            // 
            // rad_uncl
            // 
            this.rad_uncl.AutoSize = true;
            this.rad_uncl.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.rad_uncl.Location = new System.Drawing.Point(6, 54);
            this.rad_uncl.Name = "rad_uncl";
            this.rad_uncl.Size = new System.Drawing.Size(90, 24);
            this.rad_uncl.TabIndex = 8;
            this.rad_uncl.TabStop = true;
            this.rad_uncl.Text = "逆時針";
            this.rad_uncl.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(1321, 420);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 24);
            this.label2.TabIndex = 11;
            this.label2.Text = "filter_size:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(1369, 636);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 24);
            this.label3.TabIndex = 12;
            this.label3.Text = "degree:";
            // 
            // btn_pow
            // 
            this.btn_pow.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_pow.Location = new System.Drawing.Point(1562, 264);
            this.btn_pow.Name = "btn_pow";
            this.btn_pow.Size = new System.Drawing.Size(189, 91);
            this.btn_pow.TabIndex = 14;
            this.btn_pow.Text = "power-law transform";
            this.btn_pow.UseVisualStyleBackColor = true;
            this.btn_pow.Click += new System.EventHandler(this.btn_pow_Click);
            // 
            // btn_his
            // 
            this.btn_his.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_his.Location = new System.Drawing.Point(1562, 369);
            this.btn_his.Name = "btn_his";
            this.btn_his.Size = new System.Drawing.Size(189, 91);
            this.btn_his.TabIndex = 15;
            this.btn_his.Text = "histogram equalization";
            this.btn_his.UseVisualStyleBackColor = true;
            this.btn_his.Click += new System.EventHandler(this.btn_his_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(1339, 361);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 24);
            this.label4.TabIndex = 16;
            this.label4.Text = "gamma:";
            // 
            // tb_gamma
            // 
            this.tb_gamma.Location = new System.Drawing.Point(1433, 360);
            this.tb_gamma.Name = "tb_gamma";
            this.tb_gamma.Size = new System.Drawing.Size(100, 25);
            this.tb_gamma.TabIndex = 17;
            // 
            // chart_org
            // 
            chartArea1.Name = "ChartArea1";
            this.chart_org.ChartAreas.Add(chartArea1);
            this.chart_org.Location = new System.Drawing.Point(27, 369);
            this.chart_org.Name = "chart_org";
            series1.ChartArea = "ChartArea1";
            series1.Name = "Series1";
            this.chart_org.Series.Add(series1);
            this.chart_org.Size = new System.Drawing.Size(409, 318);
            this.chart_org.TabIndex = 18;
            this.chart_org.Text = "chart1";
            // 
            // chart_af
            // 
            chartArea2.Name = "ChartArea1";
            this.chart_af.ChartAreas.Add(chartArea2);
            this.chart_af.Location = new System.Drawing.Point(467, 369);
            this.chart_af.Name = "chart_af";
            series2.ChartArea = "ChartArea1";
            series2.Name = "Series1";
            this.chart_af.Series.Add(series2);
            this.chart_af.Size = new System.Drawing.Size(409, 318);
            this.chart_af.TabIndex = 19;
            this.chart_af.Text = "chart1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(1369, 313);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 19);
            this.label5.TabIndex = 20;
            this.label5.Text = "C:";
            // 
            // tb_c
            // 
            this.tb_c.Location = new System.Drawing.Point(1433, 307);
            this.tb_c.Name = "tb_c";
            this.tb_c.Size = new System.Drawing.Size(100, 25);
            this.tb_c.TabIndex = 21;
            // 
            // btn_mat
            // 
            this.btn_mat.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_mat.Location = new System.Drawing.Point(1562, 477);
            this.btn_mat.Name = "btn_mat";
            this.btn_mat.Size = new System.Drawing.Size(189, 91);
            this.btn_mat.TabIndex = 22;
            this.btn_mat.Text = "histogram matching";
            this.btn_mat.UseVisualStyleBackColor = true;
            this.btn_mat.Click += new System.EventHandler(this.btn_mat_Click);
            // 
            // chart_curves
            // 
            chartArea3.Name = "ChartArea1";
            this.chart_curves.ChartAreas.Add(chartArea3);
            this.chart_curves.Location = new System.Drawing.Point(906, 369);
            this.chart_curves.Name = "chart_curves";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Name = "Series1";
            this.chart_curves.Series.Add(series3);
            this.chart_curves.Size = new System.Drawing.Size(409, 318);
            this.chart_curves.TabIndex = 23;
            this.chart_curves.Text = "chart1";
            // 
            // tb_size
            // 
            this.tb_size.Location = new System.Drawing.Point(1433, 419);
            this.tb_size.Name = "tb_size";
            this.tb_size.Size = new System.Drawing.Size(100, 25);
            this.tb_size.TabIndex = 24;
            // 
            // bt_lap
            // 
            this.bt_lap.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.bt_lap.Location = new System.Drawing.Point(1350, 531);
            this.bt_lap.Name = "bt_lap";
            this.bt_lap.Size = new System.Drawing.Size(189, 91);
            this.bt_lap.TabIndex = 25;
            this.bt_lap.Text = "Laplacian enhancement";
            this.bt_lap.UseVisualStyleBackColor = true;
            this.bt_lap.Click += new System.EventHandler(this.bt_lap_Click);
            // 
            // bt_check
            // 
            this.bt_check.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.bt_check.Location = new System.Drawing.Point(1365, 459);
            this.bt_check.Name = "bt_check";
            this.bt_check.Size = new System.Drawing.Size(151, 55);
            this.bt_check.TabIndex = 26;
            this.bt_check.Text = "size_check";
            this.bt_check.UseVisualStyleBackColor = true;
            this.bt_check.Click += new System.EventHandler(this.bt_check_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1772, 707);
            this.Controls.Add(this.bt_check);
            this.Controls.Add(this.bt_lap);
            this.Controls.Add(this.tb_size);
            this.Controls.Add(this.chart_curves);
            this.Controls.Add(this.btn_mat);
            this.Controls.Add(this.tb_c);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.chart_af);
            this.Controls.Add(this.chart_org);
            this.Controls.Add(this.tb_gamma);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btn_his);
            this.Controls.Add(this.btn_pow);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tb_degree);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_rotating);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_Loadimage);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart_org)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart_af)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart_curves)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Loadimage;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btn_rotating;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_degree;
        private System.Windows.Forms.RadioButton rad_1;
        private System.Windows.Forms.RadioButton rad_2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rad_cl;
        private System.Windows.Forms.RadioButton rad_uncl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_pow;
        private System.Windows.Forms.Button btn_his;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_gamma;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_org;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_af;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_c;
        private System.Windows.Forms.Button btn_mat;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_curves;
        private System.Windows.Forms.TextBox tb_size;
        private System.Windows.Forms.Button bt_lap;
        private System.Windows.Forms.Button bt_check;
    }
}

